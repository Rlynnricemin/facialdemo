<template>
  <div id="_wrapper">
    <div style=“margin-top:30%”>
      <!-- <canvas id="process" width="250" height="250"></canvas> -->
      <div class="cirqueBox">
        <div class="cirqueRed" :class="{'warn': iswarn}"></div>
        <div class="cirqueGrey" v-if="!stopcircle"></div>
      </div>
      <div class="drawcanvas">
        <video  id="_webcam" playsinline class=""></video>
        <canvas id="_imageData" width="320" height="240"></canvas>
        <canvas id="_faceSub"></canvas>
        <canvas id="_t3d"></canvas>
        <canvas id="_f3d"></canvas>
        <canvas id="_drawing"></canvas>
        <div id="_stats"></div>
      </div>
      <!-- <div id="_progressBar"></div> -->
    </div>
    <p class="wz-tip" v-html="wztip" :class="{'warn': iswarn}"></p>
    <p class="time-return" v-if="!iswarn && !stopcircle">{{downtime}}</p>
    <p v-if="pass">检验通过</p>
    <!-- <p ref="imgpic"></p> -->
  </div>
</template>

<script>
import Vconsole from 'vconsole'
var color = '#6ABF8B'
var vconsole = new Vconsole()
console.log(vconsole)
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      width: 250,
      height: 250,
      downtime: 5,
      wztip: '请正视手机<br>保持禁止不动',
      eventtype: 'init',
      pass: false,
      stopcircle: false,
      iswarn: false,
      successstatus: 0
    }
  },
  created () {
  },
  mounted () {
    // this.drawCanvas()
    window.brfv4Example.start()
    window.brfv4Example.callback = this.brfv4callback
  },
  methods: {
    successback (optype) {
      if (this.successstatus === 2) {
        console.log('第二次通过啦')
        // 2次通过则显示通过
        this.pass = true
        this.stopcircle = true
        window.brfv4Example.stopCheckImg = true
        this.wztip = ''
        setTimeout(() => {
          window.brfv4Example.imageData.webcam.stopStream()
          window.brfv4Example.stop()
        }, 1000)
      } else {
        color = '#6ABF8B'
        this.successstatus += 1
        this.setwztip(optype)
        window.brfv4Example.stopCheckImg = false
        if (this.setTimeout) clearTimeout(this.setTimeout)
        this.downtime = 5
        if (optype === 1) {
          this.downtime = 5
        }
        this.countdown()
      }
    },
    errorcallback () {
      if (this.successstatus >= 2) return
      color = '#DC2F3E'
      this.wztip = '未通过验证，请重试'
      this.stopcircle = true
      this.iswarn = true
      window.brfv4Example.imageData.webcam.stopStream()
      window.brfv4Example.stop()
    },
    brfv4callback (type, status, optype) {
      this.eventtype = type
      if (type === 'init') {
        this.countdown()
      } else {
        console.log('status。。。。。。。', type + '...' + status + '.....' + optype)
        if (status === 'error') {
          this.errorcallback()
        } else {
          this.successback(optype)
        }
      }
    },
    setwztip (type) {
      if (type === 1) {
        this.wztip = '请正视手机<br>左右摇头'
      } else if (type === 2) {
        this.wztip = '请正视手机<br>张开嘴'
      } else if (type === 3) {
        this.wztip = '请正视手机<br>眨一眨眼'
      }
    },
    countdown () {
      this.setTimeout = setTimeout(() => {
        if (this.downtime === 0) {
          window.brfv4Example.stopCheckImg = true
        } else {
          this.downtime -= 1
          if (this.downtime < 3) {
            window.brfv4Example.stopCheckImg = 'passtime'
          }
          this.countdown()
        }
      }, 1000)
    },
    drawCanvas () {
      var that = this
      var c = document.getElementById('process')
      var process = 0
      var ctx = c.getContext('2d')
      // 画灰色的圆
      function init () {
        ctx.fillStyle = '#fff'
        ctx.beginPath()
        ctx.fillRect(0, 0, that.width, that.height)
        ctx.closePath()
        ctx.beginPath()
        ctx.arc(that.width / 2, that.height / 2, that.width / 2, 0, Math.PI * 2)
        ctx.closePath()
        ctx.fillStyle = '#f6f6f6'
        ctx.fill()
      }

      function animate () {
        requestAnimationFrame(function () {
          process = process + 1
          drawCricle(ctx, process)
          if (process === 100 && !that.stopcircle) {
            init()
            process = 1
          }
          animate()
        })
      }

      function drawCricle (ctx, percent) {
        // 画进度环
        ctx.beginPath()
        ctx.moveTo(that.width / 2, that.height / 2)
        ctx.arc(that.width / 2, that.height / 2, that.width / 2, Math.PI * 1.5, Math.PI * (1.5 + 2 * percent / 100))
        ctx.closePath()
        ctx.fillStyle = color
        ctx.fill()

        // 画内填充圆
        ctx.beginPath()
        ctx.arc(that.width / 2, that.height / 2, that.width / 2 - 5, 0, Math.PI * 2)
        ctx.closePath()
        ctx.fillStyle = '#fff'
        ctx.fill()
      }
      animate()
    }
  }
}
</script>

<style scoped>
.wz-tip {
  margin-top: 25px;
  font-size: 20px;
  line-height: 35px;
}
.wz-tip.warn {
  color: #DC2F3E
}
.time-return {
  font-size: 38px;
  margin-top: 10px;
  font-weight: bold;
}
html, body {
  position: absolute;
  width:  100%;
  height:  100%;
  background-color: #ffffff;
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  font-size: 16px;
  color: #005f9c;
  overflow: auto;
}
canvas {
  background-color: transparent;
  display: block;
  margin: auto;
  padding: 0;
}
video {
  position: absolute;
  background-color: transparent;
  display: none;
  margin: 0;
  padding: 0;
  left: 0;
}
#_wrapper {
  position: absolute;
  width:  100%;
  height: 80vh;
  top: 50%;
  margin-top: -40vh;
}
#_content {
  position: absolute;
  width: 250px;
  height: 250px;
  background-color: #f7f7f7;
  margin: auto;
  top: 0;
  left: 0;
  right: 0;
}
/* #_progressBar {
  position: absolute;
  width:   1px;
  height: 250px;
  background-color: #000000;
  margin: auto;
  top: 0;
  left: 0;
} */
#_subline {
  position: absolute;
  width: 250px;
  height:  40px;
  background-color: transparent;
  margin: auto;
  left: 0;
  right: 0;
  top: 490px;
}
#_highlight {
  position: absolute;
  width: 250px;
  height:  auto;
  background-color: transparent;
  margin: auto;
  left: 0;
  right: 0;
  top: 525px;
  font-size: 8pt;
}
#_brfv4_logo {
  position: absolute;
  width: 200px;
  left: 0;
  bottom: 0;
  opacity: 0.5;
}
#_stats {
  position: absolute;
  width: 80px;
  height: 48px;
  left: 0;
  top: 0;
}
#_settingsLeft {
  position: absolute;
  width: 160px;
  height: 250px;
  background-color: transparent;
}
#_settingsRight {
  position: absolute;
  width: 255px;
  height:  100%;
  background-color: transparent;
  right: 0;
}
#_msg {
  position: absolute;
  width: 100%;
  height:  40px;
  background-color: transparent;
  bottom: 0;
}
.drawcanvas {
  position: absolute;
  top: 5px;
  left: 50%;
  margin-left: -160px;
  width: 320px;
  height: 240px;
}
.drawcanvas canvas {
  position: absolute;
  top: 0;
  left: 0;
}
body {
  margin: 0;
}

.cirqueBox{
    position: relative;
    width: 250px;
    height: 250px;
    border-radius: 50%;
    -webkit-mask: radial-gradient(transparent, transparent 120px, #000 0);
    mask: radial-gradient(transparent 120px, #000 0);
    margin: auto;
}
.cirqueRed{
    position: absolute;
    width:100%;
    height: 100%;
    left:0;
    top:0;
    background-color:#6ABF8B;
    z-index: 1;
}
.cirqueRed.warn {
  background-color:#DC2F3E;
}
.cirqueGrey{
    position: absolute;
    width:100%;
    height: 100%;
    left:0;
    top:0;
    background-color:#f6f6f6;
    z-index: 2;
    animation:mymove 1.5s linear infinite;
}
@keyframes mymove
{
    0%   {
        clip-path: polygon(125px 125px, 125px -300px, -300px 70px, 70px 440px, 440px 70px, 70px -300px);
    }
    25%   {
        clip-path: polygon(125px 125px, 125px -300px, -300px 70px, 70px 440px, 440px 70px, 440px 70px);
    }
    50%   {
        clip-path: polygon(125px 125px, 125px -300px, -300px 70px, 70px 440px, 70px 440px, 70px 440px);
    }
    75%   {
        clip-path: polygon(125px 125px, 125px -300px, -300px 70px, -300px 70px, -300px 70px, -300px 70px);
    }
    100%   {
        clip-path: polygon(125px 125px, 125px -300px, 70px -300px, 70px -300px, 70px -300px, 70px -300px);
    }
}
</style>
